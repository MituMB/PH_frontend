export const Grade = ['A', 'B', 'C', 'D', 'F', 'NA'];
