export const AcademicDepartmentSearchableFields = ['name'];
