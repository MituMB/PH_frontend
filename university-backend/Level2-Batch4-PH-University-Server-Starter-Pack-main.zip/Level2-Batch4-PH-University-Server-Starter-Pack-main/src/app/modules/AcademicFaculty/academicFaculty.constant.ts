export const AcademicFacultySearchableFields = ['name'];
