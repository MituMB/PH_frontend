export type TAcademicFaculty = {
  name: string;
};
