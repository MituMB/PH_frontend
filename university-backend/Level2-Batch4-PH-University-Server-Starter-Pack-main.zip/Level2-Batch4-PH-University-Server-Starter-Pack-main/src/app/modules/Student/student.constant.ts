export const studentSearchableFields = [
  'email',
  'name.firstName',
  'name.lastName',
  'presentAddress',
];
